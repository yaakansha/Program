import os
from collections import defaultdict

def process_lap_times():
    file_paths = [
        "lap_times_1 (1).txt",
        "lap_times_2 (1).txt",
        "lap_times_3 (1).txt",
        "drivers_details(1).txt"
    ]

    results = []

    for file_path in file_paths:
        if not os.path.isfile(file_path):
            results.append(f"Error: File {file_path} does not exist.")
            continue

        with open(file_path, 'r') as file:
            lines = file.readlines()

        race_location = lines[0].strip()
        lap_times = defaultdict(list)

        for line in lines[1:]:
            driver_code = line[:3]
            lap_time = float(line[3:].strip())
            lap_times[driver_code].append(lap_time)

        fastest_time = float('inf')
        fastest_driver = None
        for driver, times in lap_times.items():
            min_time = min(times)
            if min_time < fastest_time:
                fastest_time = min_time
                fastest_driver = driver

        total_time = sum([sum(times) for times in lap_times.values()])
        total_laps = sum([len(times) for times in lap_times.values()])
        overall_avg_time = total_time / total_laps

        results.append(f"Race Location: {race_location}")
        results.append(f"Fastest Driver: {fastest_driver} with time {fastest_time:.3f}")
        results.append(f"Overall Average Time: {overall_avg_time:.3f}")
        results.append("Fastest Time for Each Driver:")
        for driver, times in lap_times.items():
            results.append(f"{driver}: {min(times):.3f}")

        results.append("Average Time for Each Driver:")
        for driver, times in lap_times.items():
            avg_time = sum(times) / len(times)
            results.append(f"{driver}: {avg_time:.3f}")

        results.append("Fastest Times in Descending Order:")
        sorted_times = sorted([(driver, min(times)) for driver, times in lap_times.items()], key=lambda x: x[1])
        for driver, time in sorted_times:
            results.append(f"{driver}: {time:.3f}")

    return '\n'.join(results)

# Example of calling the function without needing to pass the file path
print(process_lap_times())
