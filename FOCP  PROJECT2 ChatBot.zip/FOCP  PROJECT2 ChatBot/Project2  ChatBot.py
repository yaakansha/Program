import random  # For generating random agent names and responses
import json  # For handling JSON data
import datetime  # For timestamping logs
import time  # For simulating typing effects

# Function to generate a random agent name from a predefined list
def generate_agent_name():
    names = ["Pommy", "Tuntun", "Arnav", "Wolf", "Lakhaneet", "Aaku"]
    return random.choice(names)

# Function to load responses from a JSON file
def load_responses(filename):
    with open(filename, 'r') as file:
        responses = json.load(file)
    return responses

# Function to log the conversation to a file
def log_conversation(log_file, user_name, agent_name, user_input, response):
    with open(log_file, 'a') as file:
        log_entry = f"{datetime.datetime.now()}: {user_name} ({user_input}) - {agent_name} ({response})\n"
        file.write(log_entry)

# Function to simulate typing for responses
def typing_effect(text, delay=0.05):
    for char in text:
        print(char, end='', flush=True)
        time.sleep(delay)
    print()

# Function to generate a response based on user input
def generate_response(user_input, responses, user_name):
    for key_word, response in responses.items():
        if key_word in user_input:
            return response.replace("{user_name}", user_name)
    random_responses = [
        f"Interesting! Tell me more about that, {user_name}.",
        f"I see. What else would you like to know, {user_name}?",
        f"That's good to know, {user_name}."
    ]
    return random.choice(random_responses)

# Main chat function
def main():
    user_name = input("Welcome to the University of Poppleton chatbot! Please enter your name: ")
    agent_name = generate_agent_name()
    print(f"Hi {user_name}, I'm {agent_name}. How can I assist you today?")

    print("\nYou can ask about:\n- College facilities\n-course\n-contact\n- Admissions\n- Sports\n- Scholarships\n- Clubs and events\n- Location\n- Principal\n")

    # Load responses from the JSON file
    responses = load_responses("responses.json")
    log_file = f"chat_log_{user_name}.txt"

    while True:
        user_input = input("> ").lower()
        if user_input in ["bye", "exit", "quit"]:
            feedback_prompt = input("Before you go, would you like to give feedback? (Yes/No) ").lower()
            if feedback_prompt == "yes":
                feedback = input("How was your experience today? ")
                with open(log_file, 'a') as file:
                    file.write(f"{datetime.datetime.now()}: Feedback from {user_name}: {feedback}\n")
                typing_effect(f"Thank you for your feedback, {user_name}! Goodbye, and have a great day!")
            else:
                typing_effect(f"Goodbye, {user_name}! Have a great day!")
            break

        if random.random() < 0.05:  # Simulate a 5% chance of disconnection
            typing_effect("The chat has been disconnected. Please refresh to reconnect.")
            break

        response = generate_response(user_input, responses, user_name)
        typing_effect(response)
        log_conversation(log_file, user_name, agent_name, user_input, response)

# Check if the script is being run directly
if __name__ == "__main__":
    main()
